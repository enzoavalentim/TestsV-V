import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class BooleanUtilsTest {

    @Test
    void shouldEvaluateBooleanExpressionsForPrimitiveAndWrapperValues() {
        assertTrue(BooleanUtils.and(true, true, true));
        assertFalse(BooleanUtils.and(true, false, true));

        assertTrue(BooleanUtils.or(false, false, true));
        assertFalse(BooleanUtils.or(false, false, false));

        assertTrue(BooleanUtils.xor(true, false, false));
        assertFalse(BooleanUtils.xor(true, true, false));

        assertTrue(BooleanUtils.oneHot(false, true, false));
        assertFalse(BooleanUtils.oneHot(true, true, false));

        assertEquals(Boolean.TRUE, BooleanUtils.and(Boolean.TRUE, Boolean.TRUE));
        assertEquals(Boolean.FALSE, BooleanUtils.or(Boolean.FALSE, Boolean.FALSE));

        assertThrows(
                NullPointerException.class,
                () -> BooleanUtils.and(Boolean.TRUE, null)
        );
    }

    @Test
    void shouldConvertStringsAndIntegersToBooleanValues() {
        assertTrue(BooleanUtils.toBoolean("YES"));
        assertTrue(BooleanUtils.toBoolean("on"));
        assertFalse(BooleanUtils.toBoolean("OFF"));
        assertFalse(BooleanUtils.toBoolean("no"));

        assertTrue(BooleanUtils.toBoolean(5, 5, 0));
        assertFalse(BooleanUtils.toBoolean(
                Integer.valueOf(2),
                Integer.valueOf(1),
                Integer.valueOf(2)
        ));

        assertEquals(Boolean.TRUE, BooleanUtils.toBooleanObject("T"));
        assertEquals(Boolean.FALSE, BooleanUtils.toBooleanObject("No"));

        assertNull(BooleanUtils.toBooleanObject("unknown"));
        assertNull(BooleanUtils.toBooleanObject(4, 1, 2, 4));

        assertThrows(
                IllegalArgumentException.class,
                () -> BooleanUtils.toBoolean("unknown", "true", "false")
        );
    }

    @Test
    void shouldFormatBooleanValuesAndIterateOverAvailableConstants() {
        assertEquals("yes", BooleanUtils.toStringYesNo(true));
        assertEquals("no", BooleanUtils.toStringYesNo(false));

        assertEquals("on", BooleanUtils.toStringOnOff(Boolean.TRUE));
        assertEquals("off", BooleanUtils.toStringOnOff(Boolean.FALSE));

        assertNull(BooleanUtils.toStringTrueFalse((Boolean) null));

        assertEquals(100, BooleanUtils.toInteger(Boolean.TRUE, 100, 200, 300));
        assertEquals(Integer.valueOf(200), BooleanUtils.toIntegerObject(false, 100, 200));

        assertArrayEquals(
                new boolean[] {false, true},
                BooleanUtils.primitiveValues()
        );

        assertArrayEquals(
                new Boolean[] {Boolean.FALSE, Boolean.TRUE},
                BooleanUtils.booleanValues()
        );

        final List<Boolean> actualValues = new ArrayList<>();
        BooleanUtils.forEach(actualValues::add);

        assertEquals(BooleanUtils.values(), actualValues);
    }
}