```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class JoinerTest {

    @Test
    void shouldJoinMultipleElementsAndAppendToExistingBuilder() {
        final AppendableJoiner<Object> joiner = AppendableJoiner.builder()
                .setPrefix("[")
                .setSuffix("]")
                .setDelimiter(",")
                .get();

        final StringBuilder result = new StringBuilder("start");

        final StringBuilder returned = joiner.join(result, "a", 2, null);

        assertSame(result, returned);
        assertEquals("start[a,2,null]", result.toString());

        joiner.join(result, Arrays.asList("x", "y"));

        assertEquals("start[a,2,null][x,y]", result.toString());
    }

    @Test
    void shouldReturnPrefixAndSuffixForNullOrEmptyCollections() {
        final AppendableJoiner<String> joiner = AppendableJoiner.<String>builder()
                .setPrefix("(")
                .setSuffix(")")
                .setDelimiter("|")
                .get();

        final StringBuilder nullArrayResult =
                joiner.join(new StringBuilder(), (String[]) null);

        final StringBuilder emptyIterableResult =
                joiner.join(new StringBuilder(), Arrays.<String>asList());

        final StringBuilder nullIterableResult =
                joiner.join(new StringBuilder(), (Iterable<String>) null);

        assertEquals("()", nullArrayResult.toString());
        assertEquals("()", emptyIterableResult.toString());
        assertEquals("()", nullIterableResult.toString());
    }

    @Test
    void shouldApplyCustomAppenderAndPropagateIOException() throws Exception {
        final AppendableJoiner<String> joiner = AppendableJoiner.<String>builder()
                .setDelimiter("-")
                .setElementAppender(
                        (appendable, value) -> appendable.append(value.toUpperCase())
                )
                .get();

        assertEquals("A-B", joiner.joinA(new StringBuilder(), "a", "b").toString());

        final Appendable failingAppendable = new Appendable() {

            @Override
            public Appendable append(final CharSequence sequence) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(
                    final CharSequence sequence,
                    final int start,
                    final int end) throws IOException {
                throw new IOException("boom");
            }

            @Override
            public Appendable append(final char character) throws IOException {
                throw new IOException("boom");
            }
        };

        assertThrows(
                IOException.class,
                () -> joiner.joinA(failingAppendable, "a")
        );
    }
}
```