```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class BitFieldTest {

    @Test
    void shouldExtractUpdateAndResetValuesWithinIntegerMask() {
        final BitField bitField = new BitField(0x07E0);
        final int initialValue = 0xFFFF;
        final int updatedValue = bitField.setValue(initialValue, 5);

        assertEquals(5, bitField.getValue(updatedValue));
        assertEquals(5 << 5, bitField.getRawValue(updatedValue));

        assertTrue(bitField.isSet(updatedValue));
        assertFalse(bitField.isAllSet(updatedValue));

        assertEquals(initialValue & ~0x07E0, bitField.clear(initialValue));
        assertEquals(0x07E0, bitField.set(0));
        assertEquals(0, bitField.setBoolean(0x07E0, false));
    }

    @Test
    void shouldHandleByteAndShortMaskOperations() {
        final BitField byteField = new BitField(0x10);

        assertEquals(0x10, byteField.setByte((byte) 0));
        assertEquals(0, byteField.clearByte((byte) 0x10));
        assertEquals(0x10, byteField.setByteBoolean((byte) 0, true));

        final BitField shortField = new BitField(0x01E0);
        final short encodedValue = shortField.setShortValue((short) 0, (short) 6);

        assertEquals(0x00C0, encodedValue & 0xFFFF);
        assertEquals(6, shortField.getShortValue(encodedValue));
        assertEquals(0, shortField.setShortBoolean((short) 0x01E0, false));
    }

    @Test
    void shouldManipulateValuesStoredInHighLongBits() {
        final BitField highBitField = new BitField(0x0000FF0000000000L);
        final long encodedValue = highBitField.setValue(0L, 0x5CL);

        assertEquals(0x5CL, highBitField.getValue(encodedValue));
        assertEquals(0x005C0000000000L, highBitField.getRawValue(encodedValue));

        final long fullySetValue = highBitField.set(0L);
        assertTrue(highBitField.isAllSet(fullySetValue));

        final long clearedValue = highBitField.clear(encodedValue);
        assertFalse(highBitField.isSet(clearedValue));
        assertEquals(0L, highBitField.setBoolean(encodedValue, false));
    }
}
```