```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.apache.commons.lang3.arch.Processor;
import org.junit.jupiter.api.Test;

class ArchUtilsTest {

    @Test
    void shouldIdentifyX86ProcessorsByArchitectureAlias() {
        final Processor processor32 = ArchUtils.getProcessor("i386");
        final Processor processor64 = ArchUtils.getProcessor("amd64");

        assertEquals(Processor.Arch.BIT_32, processor32.getArch());
        assertEquals(Processor.Type.X86, processor32.getType());

        assertEquals(Processor.Arch.BIT_64, processor64.getArch());
        assertEquals(Processor.Type.X86, processor64.getType());
    }

    @Test
    void shouldRecognizePowerPcArmAndRiscVArchitectures() {
        final Processor powerPcProcessor = ArchUtils.getProcessor("powerpc64");
        final Processor armProcessor = ArchUtils.getProcessor("aarch64");
        final Processor riscVProcessor = ArchUtils.getProcessor("riscv32");

        assertEquals(Processor.Type.PPC, powerPcProcessor.getType());
        assertEquals(Processor.Arch.BIT_64, armProcessor.getArch());
        assertEquals(Processor.Type.RISC_V, riscVProcessor.getType());
    }

    @Test
    void shouldHandleUnknownArchitecturesAndCurrentProcessorLookup() {
        final Processor unknownProcessor =
                ArchUtils.getProcessor("not-a-real-architecture");
        final Processor nullProcessor = ArchUtils.getProcessor(null);
        final ArchUtils utilityInstance = new ArchUtils();

        assertNull(unknownProcessor);
        assertNull(nullProcessor);
        assertNotNull(utilityInstance);

        ArchUtils.getProcessor();
    }
}
```