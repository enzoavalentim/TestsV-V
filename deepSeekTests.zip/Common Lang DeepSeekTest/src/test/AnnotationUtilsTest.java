```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.junit.jupiter.api.Test;

class AnnotationUtilsTest {

    @Retention(RetentionPolicy.RUNTIME)
    @interface InnerAnnotation {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @interface TestAnnotation {
        int number();

        String text();

        int[] numbers();

        InnerAnnotation nested();
    }

    @TestAnnotation(
        number = 7,
        text = "alpha",
        numbers = {1, 2},
        nested = @InnerAnnotation("inner")
    )
    static class FirstAnnotatedClass {
    }

    @TestAnnotation(
        number = 7,
        text = "alpha",
        numbers = {1, 2},
        nested = @InnerAnnotation("inner")
    )
    static class EquivalentAnnotatedClass {
    }

    @TestAnnotation(
        number = 8,
        text = "beta",
        numbers = {2, 1},
        nested = @InnerAnnotation("other")
    )
    static class DifferentAnnotatedClass {
    }

    @Test
    void shouldCompareAnnotationsUsingAllMembers() {
        final TestAnnotation first =
                FirstAnnotatedClass.class.getAnnotation(TestAnnotation.class);
        final TestAnnotation equivalent =
                EquivalentAnnotatedClass.class.getAnnotation(TestAnnotation.class);
        final TestAnnotation different =
                DifferentAnnotatedClass.class.getAnnotation(TestAnnotation.class);

        assertTrue(AnnotationUtils.equals(first, equivalent));
        assertFalse(AnnotationUtils.equals(first, different));
        assertFalse(AnnotationUtils.equals(first, null));
    }

    @Test
    void shouldGenerateConsistentHashCodesAndAnnotationString() {
        final TestAnnotation first =
                FirstAnnotatedClass.class.getAnnotation(TestAnnotation.class);
        final TestAnnotation equivalent =
                EquivalentAnnotatedClass.class.getAnnotation(TestAnnotation.class);

        assertEquals(
                AnnotationUtils.hashCode(first),
                AnnotationUtils.hashCode(equivalent)
        );

        final String annotationString = AnnotationUtils.toString(first);

        assertNotNull(annotationString);
        assertTrue(annotationString.contains("number=7"));
    }

    @Test
    void shouldValidateAnnotationMemberTypes() {
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(String.class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(int[].class));
        assertTrue(AnnotationUtils.isValidAnnotationMemberType(InnerAnnotation.class));

        assertFalse(AnnotationUtils.isValidAnnotationMemberType(Object.class));
        assertFalse(AnnotationUtils.isValidAnnotationMemberType(null));

        final TestAnnotation first =
                FirstAnnotatedClass.class.getAnnotation(TestAnnotation.class);
        final TestAnnotation different =
                DifferentAnnotatedClass.class.getAnnotation(TestAnnotation.class);

        assertNotEquals(
                AnnotationUtils.hashCode(first),
                AnnotationUtils.hashCode(different)
        );
    }
}
```