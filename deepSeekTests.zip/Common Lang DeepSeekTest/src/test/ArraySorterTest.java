```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Comparator;

import org.junit.jupiter.api.Test;

class SorterTest {

    @Test
    void shouldSortPrimitiveArraysWithoutCreatingNewInstances() {
        final int[] integers = {5, 2, 8, 1};
        final long[] longs = {12L, 3L, 7L, 1L};
        final char[] characters = {'d', 'a', 'c', 'b'};

        final int[] sortedIntegers = ArraySorter.sort(integers);
        final long[] sortedLongs = ArraySorter.sort(longs);
        final char[] sortedCharacters = ArraySorter.sort(characters);

        assertSame(integers, sortedIntegers);
        assertSame(longs, sortedLongs);
        assertSame(characters, sortedCharacters);

        assertArrayEquals(new int[] {1, 2, 5, 8}, integers);
        assertArrayEquals(new long[] {1L, 3L, 7L, 12L}, longs);
        assertArrayEquals(new char[] {'a', 'b', 'c', 'd'}, characters);
    }

    @Test
    void shouldSupportNaturalAndReverseOrderingForObjects() {
        final String[] ascendingNames = {"Maria", "Ana", "Carlos", "Bruno"};
        final String[] descendingNames = {"Maria", "Ana", "Carlos", "Bruno"};

        ArraySorter.sort(ascendingNames);
        ArraySorter.sort(descendingNames, Comparator.reverseOrder());

        assertArrayEquals(
                new String[] {"Ana", "Bruno", "Carlos", "Maria"},
                ascendingNames
        );

        assertArrayEquals(
                new String[] {"Maria", "Carlos", "Bruno", "Ana"},
                descendingNames
        );
    }

    @SuppressWarnings("deprecation")
    @Test
    void shouldHandleNullInputsAndMaintainConstructorCompatibility() {
        assertNull(ArraySorter.sort((int[]) null));
        assertNull(ArraySorter.sort((String[]) null));
        assertNull(ArraySorter.sort(null, Comparator.naturalOrder()));

        final ArraySorter sorter = new ArraySorter();
        assertSame(ArraySorter.class, sorter.getClass());
    }
}
```