```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ArrayUtilsTest {

    @Test
    void shouldAppendInsertAndCombineArrayElements() {
        final int[] original = {4, 8, 12};

        assertArrayEquals(
                new int[] {4, 8, 12, 16},
                ArrayUtils.add(original, 16)
        );

        assertArrayEquals(
                new int[] {4, 6, 8, 12},
                ArrayUtils.add(original, 1, 6)
        );

        assertArrayEquals(
                new int[] {4, 8, 12, 20, 24},
                ArrayUtils.addAll(original, 20, 24)
        );

        assertArrayEquals(
                new int[] {4, 15, 18, 8, 12},
                ArrayUtils.insert(1, original, 15, 18)
        );

        assertArrayEquals(
                new int[] {4, 8, 12},
                original
        );

        assertThrows(
                IndexOutOfBoundsException.class,
                () -> ArrayUtils.add(original, 5, 99)
        );
    }

    @Test
    void shouldCloneArraysAndSearchForExistingOrMissingValues() {
        final String[] elements = {"Java", null, "Python", "Kotlin"};
        final String[] copiedElements = ArrayUtils.clone(elements);

        assertArrayEquals(elements, copiedElements);
        assertNull(ArrayUtils.clone((Object[]) null));

        assertTrue(ArrayUtils.contains(elements, null));
        assertTrue(ArrayUtils.contains(elements, "Python"));
        assertFalse(ArrayUtils.contains(elements, "Ruby"));

        assertTrue(ArrayUtils.contains(new int[] {5, 10, 15}, 10));
        assertFalse(ArrayUtils.contains(new int[] {5, 10, 15}, 20));

        assertEquals(2, ArrayUtils.indexOf(elements, "Python"));
        assertEquals(0, ArrayUtils.indexOf(elements, "Java"));
        assertEquals(
                ArrayUtils.INDEX_NOT_FOUND,
                ArrayUtils.indexOf(elements, "Ruby")
        );
    }

    @Test
    void shouldManipulateArrayOrderAndConvertBetweenPrimitiveAndWrapperTypes() {
        final int[] values = {10, 20, 30, 40, 50};

        assertArrayEquals(
                new int[] {20, 30, 40},
                ArrayUtils.subarray(values, 1, 4)
        );

        ArrayUtils.reverse(values);
        assertArrayEquals(new int[] {50, 40, 30, 20, 10}, values);

        ArrayUtils.swap(values, 1, 3);
        assertArrayEquals(new int[] {50, 20, 30, 40, 10}, values);

        assertArrayEquals(
                new int[] {3, 6, 9},
                ArrayUtils.toPrimitive(new Integer[] {3, 6, 9})
        );

        assertArrayEquals(
                new Integer[] {3, 6, 9},
                ArrayUtils.toObject(new int[] {3, 6, 9})
        );
    }
}
```