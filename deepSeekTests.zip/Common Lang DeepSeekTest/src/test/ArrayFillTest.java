```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;

import org.junit.jupiter.api.Test;

class FillTest {

    @Test
    void shouldFillPrimitiveArraysAndPreserveTheirReferences() {
        final int[] integerArray = {1, 2, 3};
        final char[] characterArray = {'a', 'b', 'c'};
        final boolean[] booleanArray = {false, false};

        final int[] filledIntegers = ArrayFill.fill(integerArray, 9);
        final char[] filledCharacters = ArrayFill.fill(characterArray, 1, 3, 'z');
        final boolean[] filledBooleans = ArrayFill.fill(booleanArray, true);

        assertSame(integerArray, filledIntegers);
        assertSame(characterArray, filledCharacters);
        assertSame(booleanArray, filledBooleans);

        assertArrayEquals(new int[] {9, 9, 9}, integerArray);
        assertArrayEquals(new char[] {'a', 'z', 'z'}, characterArray);
        assertArrayEquals(new boolean[] {true, true}, booleanArray);
    }

    @Test
    void shouldClearByteAndCharacterArrays() {
        final byte[] clearedBytes = ArrayFill.clear(new byte[] {1, 2});
        final char[] clearedCharacters =
                ArrayFill.clear(new char[] {'a', 'x', 'b'}, 0, 3);

        assertArrayEquals(new byte[] {0, 0}, clearedBytes);
        assertArrayEquals(new char[] {0, 'x', 0}, clearedCharacters);

        assertNull(ArrayFill.clear((byte[]) null));
        assertNull(ArrayFill.clear((char[]) null));
    }

    @Test
    void shouldFillObjectArraysUsingValuesOrGenerators() throws Throwable {
        final String[] originalValues = {"a", "b"};

        final String[] filledValues = ArrayFill.fill(originalValues, "x");

        assertSame(originalValues, filledValues);
        assertArrayEquals(new String[] {"x", "x"}, originalValues);

        final Integer[] generatedValues =
                ArrayFill.fill(new Integer[3], index -> index * 2);

        assertArrayEquals(new Integer[] {0, 2, 4}, generatedValues);

        assertNull(ArrayFill.fill((String[]) null, "x"));
        assertNull(ArrayFill.fill((String[]) null, index -> "x"));

        assertThrows(IOException.class, () ->
                ArrayFill.fill(new String[2], index -> {
                    throw new IOException("stop");
                })
        );
    }
}
```