```java
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;

class CloseablesTest {

    @Test
    void shouldCloseResourcesSafelyAndRethrowFailures() throws Exception {
        final AtomicInteger closeCounter = new AtomicInteger();

        AutoCloseables.close((AutoCloseable) null);
        AutoCloseables.close(closeCounter::incrementAndGet);

        assertEquals(1, closeCounter.get());

        final IOException exception = assertThrows(
                IOException.class,
                () -> AutoCloseables.close(() -> {
                    throw new IOException("resource failure");
                })
        );

        assertEquals("resource failure", exception.getMessage());
    }

    @Test
    void shouldSendCloseExceptionsToTheProvidedHandler() throws Exception {
        final AtomicReference<Exception> receivedException = new AtomicReference<>();

        AutoCloseables.close(
                () -> {
                    throw new Exception("closing failed");
                },
                receivedException::set
        );

        assertEquals("closing failed", receivedException.get().getMessage());
    }

    @Test
    void shouldCloseQuietlyAndPreserveSuppressedExceptions() {
        final AtomicInteger closeCounter = new AtomicInteger();

        AutoCloseables.closeQuietly((AutoCloseable) null);
        AutoCloseables.closeQuietly((AutoCloseable) closeCounter::incrementAndGet);

        AutoCloseables.closeQuietly(
                Arrays.asList(
                        (AutoCloseable) closeCounter::incrementAndGet,
                        null
                )
        );

        assertEquals(2, closeCounter.get());

        final AtomicReference<Exception> handledException = new AtomicReference<>();

        AutoCloseables.closeQuietly(
                (AutoCloseable) () -> {
                    throw new Exception("ignored failure");
                },
                handledException::set
        );

        assertEquals("ignored failure", handledException.get().getMessage());

        final IllegalStateException primaryException =
                new IllegalStateException("primary failure");

        final Closeable resource = () -> {
            throw new IOException("secondary failure");
        };

        final IllegalStateException result =
                AutoCloseables.closeQuietlySuppress(resource, primaryException);

        assertSame(primaryException, result);
        assertEquals(1, primaryException.getSuppressed().length);
        assertEquals(
                "secondary failure",
                primaryException.getSuppressed()[0].getMessage()
        );
    }
}
```