import subprocess

import pytest

from cookiecutter import vcs
from cookiecutter.exceptions import (
    RepositoryCloneFailed,
    RepositoryNotFound,
    UnknownRepoType,
    VCSNotInstalled,
)


def test_repository_identification_resolves_explicit_and_default_vcs_types():
    git_url = "git+https://example.com/repo"
    bitbucket_url = "https://bitbucket.org/team/repo"

    assert vcs.identify_repo(git_url) == (
        "git",
        "https://example.com/repo",
    )
    assert vcs.identify_repo(bitbucket_url) == (
        "hg",
        bitbucket_url,
    )


def test_repository_identification_rejects_unsupported_vcs_prefix():
    unsupported_repository_url = "svn+https://example.com/repo"

    with pytest.raises(UnknownRepoType):
        vcs.identify_repo(unsupported_repository_url)


def test_vcs_installation_check_uses_executable_lookup(monkeypatch):
    available_executables = {
        "git": "/usr/bin/git",
    }

    monkeypatch.setattr(
        vcs,
        "which",
        lambda executable: available_executables.get(executable),
    )

    assert vcs.is_vcs_installed("git") is True
    assert vcs.is_vcs_installed("hg") is False


def test_clone_raises_exception_when_version_control_is_unavailable(
    monkeypatch,
    tmp_path,
):
    monkeypatch.setattr(
        vcs,
        "is_vcs_installed",
        lambda _repository_type: False,
    )

    repository_url = "git+https://example.com/repo.git"

    with pytest.raises(VCSNotInstalled):
        vcs.clone(
            repository_url,
            clone_to_dir=tmp_path,
        )


def test_clone_translates_repository_and_checkout_failures(
    monkeypatch,
    tmp_path,
):
    monkeypatch.setattr(
        vcs,
        "is_vcs_installed",
        lambda _repository_type: True,
    )

    repository_url = "git+https://example.com/repo.git"

    def simulate_missing_repository(*_args, **_kwargs):
        raise subprocess.CalledProcessError(
            1,
            "git",
            output=b"not found",
        )

    monkeypatch.setattr(
        vcs.subprocess,
        "check_output",
        simulate_missing_repository,
    )

    with pytest.raises(RepositoryNotFound):
        vcs.clone(
            repository_url,
            clone_to_dir=tmp_path,
        )

    def simulate_invalid_checkout(*_args, **_kwargs):
        raise subprocess.CalledProcessError(
            1,
            "git",
            output=b"error: pathspec",
        )

    monkeypatch.setattr(
        vcs.subprocess,
        "check_output",
        simulate_invalid_checkout,
    )

    with pytest.raises(RepositoryCloneFailed):
        vcs.clone(
            repository_url,
            checkout="missing",
            clone_to_dir=tmp_path,
        )
