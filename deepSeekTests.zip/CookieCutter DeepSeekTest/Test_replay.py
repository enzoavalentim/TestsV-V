import json

import pytest

from cookiecutter import replay


def test_replay_filename_appends_json_extension_only_when_needed(tmp_path):
    filename_without_extension = replay.get_file_name(tmp_path, "demo")
    filename_with_extension = replay.get_file_name(tmp_path, "demo.json")

    assert filename_without_extension.endswith("demo.json")
    assert filename_with_extension.endswith("demo.json")


def test_replay_context_can_be_serialized_and_loaded_without_data_loss(tmp_path):
    original_context = {
        "cookiecutter": {
            "project": "demo",
        },
    }

    replay.dump(tmp_path, "demo", original_context)

    replay_file = tmp_path / "demo.json"
    serialized_context = json.loads(
        replay_file.read_text(encoding="utf-8")
    )
    loaded_context = replay.load(tmp_path, "demo")

    assert serialized_context == original_context
    assert loaded_context == original_context


def test_replay_dump_and_load_reject_context_without_cookiecutter_key(tmp_path):
    invalid_context = {"other": {}}

    with pytest.raises(ValueError):
        replay.dump(tmp_path, "bad", invalid_context)

    replay_file = tmp_path / "bad.json"
    replay_file.write_text(
        json.dumps(invalid_context),
        encoding="utf-8",
    )

    with pytest.raises(ValueError):
        replay.load(tmp_path, "bad")
