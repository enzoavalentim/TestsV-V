import os

import pytest

from cookiecutter import config
from cookiecutter.exceptions import (
    ConfigDoesNotExistException,
    InvalidConfiguration,
)


def test_expand_path_resolves_environment_variables_and_home_directory(
    monkeypatch,
    tmp_path,
):
    monkeypatch.setenv("COOKIECUTTER_TEST_HOME", str(tmp_path))
    path_to_expand = "$COOKIECUTTER_TEST_HOME/project"

    expanded_path = config._expand_path(path_to_expand)

    expected_path = os.path.join(str(tmp_path), "project")
    assert expanded_path == expected_path


def test_merge_configs_overrides_values_and_preserves_default_configuration():
    default_config = {
        "nested": {
            "keep": "yes",
            "replace": "old",
        },
        "plain": "old",
    }
    override_config = {
        "nested": {"replace": "new"},
        "plain": "new",
    }

    merged_config = config.merge_configs(default_config, override_config)

    expected_config = {
        "nested": {
            "keep": "yes",
            "replace": "new",
        },
        "plain": "new",
    }

    assert merged_config == expected_config
    assert default_config["nested"]["replace"] == "old"
    assert default_config["plain"] == "old"


def test_get_config_loads_yaml_and_expands_configured_directories(tmp_path):
    config_file = tmp_path / "cookiecutterrc"
    config_file.write_text(
        "cookiecutters_dir: $HOME/custom-cookiecutters\n"
        "replay_dir: ~/custom-replay\n",
        encoding="utf-8",
    )

    loaded_config = config.get_config(config_file)

    assert loaded_config["cookiecutters_dir"].endswith(
        "custom-cookiecutters"
    )
    assert loaded_config["replay_dir"].endswith("custom-replay")


def test_get_config_raises_errors_for_missing_file_and_invalid_structure(
    tmp_path,
):
    missing_config = tmp_path / "missing.yml"

    with pytest.raises(ConfigDoesNotExistException):
        config.get_config(missing_config)

    invalid_config = tmp_path / "invalid.yml"
    invalid_config.write_text(
        "- not\n"
        "- a\n"
        "- mapping\n",
        encoding="utf-8",
    )

    with pytest.raises(InvalidConfiguration):
        config.get_config(invalid_config)
