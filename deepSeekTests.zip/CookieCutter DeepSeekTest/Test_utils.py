import os
import stat

from jinja2 import Environment

from cookiecutter import utils
from cookiecutter.environment import StrictEnvironment


def test_directory_creation_creates_all_missing_parent_directories(tmp_path):
    target_directory = tmp_path / "a" / "b"

    utils.make_sure_path_exists(target_directory)

    assert target_directory.is_dir()


def test_working_directory_context_manager_restores_original_location(
    tmp_path,
):
    original_directory = os.getcwd()

    with utils.work_in(tmp_path):
        assert os.getcwd() == str(tmp_path)

    assert os.getcwd() == original_directory


def test_make_executable_sets_execute_permission_on_script(tmp_path):
    script_file = tmp_path / "script.sh"
    script_file.write_text("#!/bin/sh\n", encoding="utf-8")

    utils.make_executable(script_file)

    file_mode = os.stat(script_file).st_mode
    assert file_mode & stat.S_IEXEC


def test_simple_filter_registers_custom_function_with_jinja_environment():
    def shout(value):
        return value.upper()

    environment = Environment(
        extensions=[utils.simple_filter(shout)],
    )
    rendered_output = environment.from_string(
        "{{ 'hi'|shout }}"
    ).render()

    assert rendered_output == "HI"


def test_temporary_repository_creation_copies_repository_contents(tmp_path):
    source_repository = tmp_path / "repo"
    source_repository.mkdir()

    configuration_file = source_repository / "cookiecutter.json"
    configuration_file.write_text("{}", encoding="utf-8")

    copied_repository = utils.create_tmp_repo_dir(source_repository)

    try:
        assert copied_repository.name == source_repository.name
        assert (copied_repository / "cookiecutter.json").is_file()
    finally:
        utils.rmtree(copied_repository.parent)


def test_environment_creation_applies_custom_jinja_variable_delimiters():
    template_context = {
        "cookiecutter": {
            "_jinja2_env_vars": {
                "variable_start_string": "[[",
            },
        },
    }

    environment = utils.create_env_with_context(template_context)

    assert isinstance(environment, StrictEnvironment)
    assert environment.variable_start_string == "[["
