from pathlib import Path
from zipfile import ZipFile

import pytest

from cookiecutter.exceptions import InvalidZipRepository
from cookiecutter.zipfile import unzip


def test_unzip_extracts_archive_and_returns_top_level_repository_directory(
    tmp_path,
):
    archive_path = tmp_path / "repo.zip"
    extraction_directory = tmp_path / "cache"

    with ZipFile(archive_path, "w") as archive:
        archive.writestr("repo/", "")
        archive.writestr("repo/cookiecutter.json", "{}")

    repository_path = unzip(
        str(archive_path),
        is_url=False,
        clone_to_dir=extraction_directory,
    )

    assert repository_path.endswith("repo")
    assert Path(repository_path, "cookiecutter.json").is_file()


def test_unzip_rejects_empty_archives_and_archives_without_root_directory(
    tmp_path,
):
    empty_archive = tmp_path / "empty.zip"

    with ZipFile(empty_archive, "w"):
        pass

    with pytest.raises(InvalidZipRepository, match="empty"):
        unzip(
            str(empty_archive),
            is_url=False,
            clone_to_dir=tmp_path / "cache_empty",
        )

    archive_without_root = tmp_path / "bad.zip"

    with ZipFile(archive_without_root, "w") as archive:
        archive.writestr("cookiecutter.json", "{}")

    with pytest.raises(InvalidZipRepository, match="top-level"):
        unzip(
            str(archive_without_root),
            is_url=False,
            clone_to_dir=tmp_path / "cache_invalid",
        )


def test_unzip_downloads_remote_archive_using_mocked_http_response(
    tmp_path,
    monkeypatch,
):
    source_archive = tmp_path / "source.zip"

    with ZipFile(source_archive, "w") as archive:
        archive.writestr("repo/", "")
        archive.writestr("repo/cookiecutter.json", "{}")

    archive_content = source_archive.read_bytes()

    class MockResponse:
        def iter_content(self, chunk_size):
            assert chunk_size == 1024
            yield archive_content

    monkeypatch.setattr(
        "cookiecutter.zipfile.requests.get",
        lambda *_args, **_kwargs: MockResponse(),
    )

    repository_path = unzip(
        "https://example.com/repo.zip",
        is_url=True,
        clone_to_dir=tmp_path / "cache",
        no_input=True,
    )

    assert repository_path.endswith("repo")
