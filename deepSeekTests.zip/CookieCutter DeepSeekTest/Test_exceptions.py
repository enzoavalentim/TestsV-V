from jinja2 import TemplateError

from cookiecutter.exceptions import (
    CookiecutterException,
    UndefinedVariableInTemplate,
)


def test_undefined_variable_error_message_contains_context_and_cause():
    template_error = TemplateError("missing variable")
    exception = UndefinedVariableInTemplate(
        "Unable to render",
        template_error,
        {"cookiecutter": {}},
    )

    error_message = str(exception)

    expected_details = (
        "Unable to render",
        "missing variable",
        "cookiecutter",
    )

    for detail in expected_details:
        assert detail in error_message


def test_undefined_variable_exception_inherits_cookiecutter_base_exception():
    assert issubclass(
        UndefinedVariableInTemplate,
        CookiecutterException,
    )
