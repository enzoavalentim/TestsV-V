import pytest

from cookiecutter import repository
from cookiecutter.exceptions import RepositoryNotFound


def test_repository_helpers_recognize_git_urls_and_zip_archives():
    git_repository_url = "https://example.com/repo.git"
    local_template_path = "local-template"
    zip_archive = "template.ZIP"
    unsupported_archive = "template.tar.gz"

    assert repository.is_repo_url(git_repository_url) is True
    assert repository.is_repo_url(local_template_path) is False
    assert repository.is_zip_file(zip_archive) is True
    assert repository.is_zip_file(unsupported_archive) is False


def test_repository_abbreviations_resolve_exact_prefix_and_unknown_values():
    abbreviation_map = {
        "gh": "https://github.com/{0}.git",
        "local": "template-dir",
    }

    assert (
        repository.expand_abbreviations("local", abbreviation_map)
        == "template-dir"
    )
    assert (
        repository.expand_abbreviations("gh:owner/repo", abbreviation_map)
        == "https://github.com/owner/repo.git"
    )
    assert (
        repository.expand_abbreviations("plain", abbreviation_map)
        == "plain"
    )


def test_repository_validation_requires_cookiecutter_json_in_directory(
    tmp_path,
):
    repository_directory = tmp_path / "repo"
    repository_directory.mkdir()

    assert (
        repository.repository_has_cookiecutter_json(
            str(repository_directory)
        )
        is False
    )

    configuration_file = repository_directory / "cookiecutter.json"
    configuration_file.write_text("{}", encoding="utf-8")

    assert (
        repository.repository_has_cookiecutter_json(
            str(repository_directory)
        )
        is True
    )


def test_determine_repo_dir_returns_requested_local_subdirectory(tmp_path):
    repository_directory = tmp_path / "repo"
    template_directory = repository_directory / "nested"
    template_directory.mkdir(parents=True)

    configuration_file = template_directory / "cookiecutter.json"
    configuration_file.write_text("{}", encoding="utf-8")

    resolved_directory, cleanup_required = repository.determine_repo_dir(
        str(repository_directory),
        {},
        tmp_path / "clone-cache",
        None,
        True,
        directory="nested",
    )

    assert resolved_directory == str(template_directory)
    assert cleanup_required is False


def test_determine_repo_dir_raises_exception_when_repository_is_missing(
    tmp_path,
):
    missing_repository = "missing"

    with pytest.raises(RepositoryNotFound):
        repository.determine_repo_dir(
            missing_repository,
            {},
            tmp_path,
            None,
            True,
        )
