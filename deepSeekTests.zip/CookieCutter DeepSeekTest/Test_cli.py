
from collections import OrderedDict

import click
import pytest

from cookiecutter import cli


def test_version_information_includes_application_and_runtime():
    version_information = cli.version_msg()

    expected_components = ("Cookiecutter", "Python")
    for component in expected_components:
        assert component in version_information


def test_extra_context_preserves_key_value_pairs_and_order():
    context_arguments = (
        "project_name=sample",
        "release=2.5",
        "enabled=true",
    )

    parsed_context = cli.validate_extra_context(
        None,
        None,
        context_arguments,
    )

    expected_context = OrderedDict(
        [
            ("project_name", "sample"),
            ("release", "2.5"),
            ("enabled", "true"),
        ]
    )

    assert isinstance(parsed_context, OrderedDict)
    assert parsed_context == expected_context
    assert list(parsed_context.keys()) == list(expected_context.keys())


def test_extra_context_raises_error_when_argument_has_no_separator():
    malformed_arguments = ("invalid_argument",)

    with pytest.raises(click.BadParameter):
        cli.validate_extra_context(None, None, malformed_arguments)


def test_template_listing_excludes_directories_without_template_config(
    tmp_path,
    monkeypatch,
    capsys,
):
    templates_directory = tmp_path / "available_templates"
    configured_template = templates_directory / "starter"
    unconfigured_template = templates_directory / "unfinished"

    configured_template.mkdir(parents=True)
    unconfigured_template.mkdir()

    config_file = configured_template / "cookiecutter.json"
    config_file.write_text("{}", encoding="utf-8")

    monkeypatch.setattr(
        cli,
        "get_user_config",
        lambda *_args: {
            "cookiecutters_dir": str(templates_directory),
        },
    )

    cli.list_installed_templates(False, None)

    terminal_output = capsys.readouterr().out

    assert "1 installed templates" in terminal_output
    assert "starter" in terminal_output
    assert "unfinished" not in terminal_output
