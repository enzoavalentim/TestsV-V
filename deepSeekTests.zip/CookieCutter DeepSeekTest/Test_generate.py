from collections import OrderedDict

import pytest
from jinja2 import FileSystemLoader

from cookiecutter.environment import StrictEnvironment
from cookiecutter.exceptions import (
    ContextDecodingException,
    OutputDirExistsException,
)
from cookiecutter.generate import (
    apply_overwrites_to_context,
    generate_context,
    generate_file,
    is_copy_only_path,
    render_and_create_dir,
)
from cookiecutter.utils import work_in


def test_copy_only_path_matches_configured_patterns_and_handles_missing_config():
    template_context = {
        "cookiecutter": {
            "_copy_without_render": ["*.png", "static/*"],
        },
    }

    assert is_copy_only_path("logo.png", template_context)
    assert is_copy_only_path("static/app.js", template_context)
    assert not is_copy_only_path("README.md", template_context)
    assert not is_copy_only_path("README.md", {"cookiecutter": {}})


def test_context_overwrites_update_choices_booleans_and_nested_mappings():
    context = {
        "color": ["red", "blue"],
        "enabled": False,
        "meta": {"name": "old"},
    }
    overrides = {
        "color": "blue",
        "enabled": "yes",
        "meta": {"name": "new", "extra": "value"},
    }

    apply_overwrites_to_context(context, overrides)

    assert context["color"][0] == "blue"
    assert context["enabled"] is True
    assert context["meta"] == {"name": "new", "extra": "value"}


def test_context_overwrites_raise_error_for_unsupported_choice():
    original_context = {"color": ["red"]}
    invalid_overwrite = {"color": "green"}

    with pytest.raises(ValueError):
        apply_overwrites_to_context(original_context, invalid_overwrite)


def test_generate_context_loads_json_and_applies_extra_values(tmp_path):
    context_file = tmp_path / "cookiecutter.json"
    context_file.write_text(
        '{"project": "demo", "license": ["MIT", "BSD"]}',
        encoding="utf-8",
    )

    generated_context = generate_context(
        str(context_file),
        extra_context={"license": "BSD"},
    )

    expected_context = OrderedDict(
        [
            (
                "cookiecutter",
                OrderedDict(
                    [
                        ("project", "demo"),
                        ("license", ["BSD", "MIT"]),
                    ]
                ),
            ),
        ]
    )

    assert generated_context == expected_context


def test_generate_context_raises_decoding_exception_for_malformed_json(tmp_path):
    context_file = tmp_path / "cookiecutter.json"
    context_file.write_text("{invalid", encoding="utf-8")

    with pytest.raises(ContextDecodingException):
        generate_context(str(context_file))


def test_render_directory_creates_output_and_rejects_duplicate_path(tmp_path):
    environment = StrictEnvironment()
    template_context = {"cookiecutter": {"project": "demo"}}
    directory_template = "{{ cookiecutter.project }}"

    output_directory, was_created = render_and_create_dir(
        directory_template,
        template_context,
        tmp_path,
        environment,
    )

    assert output_directory.is_dir()
    assert was_created is True

    with pytest.raises(OutputDirExistsException):
        render_and_create_dir(
            directory_template,
            template_context,
            tmp_path,
            environment,
        )


def test_generate_file_renders_template_filename_and_file_contents(tmp_path):
    template_directory = tmp_path / "template"
    output_directory = tmp_path / "output"
    template_directory.mkdir()
    output_directory.mkdir()

    template_filename = "{{ cookiecutter.name }}.txt"
    template_file = template_directory / template_filename
    template_file.write_text(
        "Hello {{ cookiecutter.name }}\n",
        encoding="utf-8",
    )

    environment = StrictEnvironment()
    environment.loader = FileSystemLoader(str(template_directory))
    template_context = {"cookiecutter": {"name": "World"}}

    with work_in(template_directory):
        generate_file(
            str(output_directory),
            template_filename,
            template_context,
            environment,
        )

    generated_file = output_directory / "World.txt"
    assert generated_file.read_text(encoding="utf-8") == "Hello World"
