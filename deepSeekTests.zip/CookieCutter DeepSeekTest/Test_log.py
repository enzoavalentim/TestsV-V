import logging

from cookiecutter.log import configure_logger


def test_logger_configuration_replaces_existing_handlers_and_sets_stream_level():
    cookiecutter_logger = logging.getLogger("cookiecutter")
    cookiecutter_logger.addHandler(logging.NullHandler())

    configured_logger = configure_logger(stream_level="INFO")

    assert configured_logger is cookiecutter_logger
    assert configured_logger.level == logging.DEBUG
    assert len(configured_logger.handlers) == 1

    stream_handler = configured_logger.handlers[0]
    assert isinstance(stream_handler, logging.StreamHandler)
    assert stream_handler.level == logging.INFO


def test_logger_configuration_writes_debug_messages_to_file(tmp_path):
    log_file = tmp_path / "debug.log"

    configured_logger = configure_logger(
        stream_level="DEBUG",
        debug_file=str(log_file),
    )
    configured_logger.debug("Debug message for testing")

    assert len(configured_logger.handlers) == 2
    assert "Debug message for testing" in log_file.read_text(
        encoding="utf-8",
    )
