import pytest
from jinja2 import UndefinedError

from cookiecutter.environment import StrictEnvironment
from cookiecutter.exceptions import UnknownExtension


def test_environment_registers_expected_filters_and_global_functions():
    environment = StrictEnvironment()

    expected_filters = {"jsonify", "slugify"}
    expected_globals = {"random_ascii_string", "uuid4"}

    assert expected_filters.issubset(environment.filters.keys())
    assert expected_globals.issubset(environment.globals.keys())


def test_environment_rejects_undefined_template_variables():
    environment = StrictEnvironment()
    template = environment.from_string("{{ missing }}")

    with pytest.raises(UndefinedError):
        template.render()


def test_environment_raises_unknown_extension_error_for_invalid_extension():
    template_context = {
        "cookiecutter": {
            "_extensions": ["does.not.Exist"],
        },
    }

    with pytest.raises(UnknownExtension):
        StrictEnvironment(context=template_context)
