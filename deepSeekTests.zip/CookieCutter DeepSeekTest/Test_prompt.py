from collections import OrderedDict

import pytest
from jinja2 import UndefinedError
from rich.prompt import InvalidResponse

from cookiecutter.environment import StrictEnvironment
from cookiecutter.prompt import (
    YesNoPrompt,
    choose_nested_template,
    process_json,
    prompt_choice_for_config,
    prompt_for_config,
    render_variable,
)


def test_yes_no_prompt_converts_supported_responses_and_rejects_invalid_input():
    prompt = YesNoPrompt()

    assert prompt.process_response("YES") is True
    assert prompt.process_response("off") is False

    with pytest.raises(InvalidResponse):
        prompt.process_response("maybe")


def test_json_processing_preserves_key_order_and_rejects_non_mapping_data():
    json_content = '{"a": 1, "b": 2}'

    parsed_content = process_json(json_content)

    expected_content = OrderedDict([
        ("a", 1),
        ("b", 2),
    ])

    assert parsed_content == expected_content
    assert list(parsed_content.keys()) == ["a", "b"]

    with pytest.raises(InvalidResponse):
        process_json("[1, 2]")


def test_variable_rendering_supports_nested_values_and_jinja_expressions():
    environment = StrictEnvironment()
    template_context = {"project": "Demo App"}
    variables = {
        "slug": "{{ cookiecutter.project.lower().replace(' ', '-') }}",
        "enabled": True,
    }

    rendered_variables = render_variable(
        environment,
        variables,
        template_context,
    )

    assert rendered_variables == {
        "slug": "demo-app",
        "enabled": True,
    }


def test_choice_prompt_returns_first_rendered_option_without_user_input():
    environment = StrictEnvironment()
    available_choices = [
        "{{ cookiecutter.name }}-MIT",
        "BSD",
    ]

    selected_choice = prompt_choice_for_config(
        {"name": "demo"},
        environment,
        "license",
        available_choices,
        no_input=True,
    )

    assert selected_choice == "demo-MIT"


def test_choice_prompt_raises_error_when_no_options_are_available():
    environment = StrictEnvironment()

    with pytest.raises(ValueError):
        prompt_choice_for_config(
            {},
            environment,
            "empty",
            [],
            no_input=True,
        )


def test_config_prompt_renders_values_and_preserves_private_configuration_keys():
    template_context = {
        "cookiecutter": OrderedDict([
            ("project", "Demo"),
            ("slug", "{{ cookiecutter.project|lower }}"),
            ("_copy_without_render", ["*.png"]),
        ]),
    }

    prompted_config = prompt_for_config(
        template_context,
        no_input=True,
    )

    assert prompted_config["project"] == "Demo"
    assert prompted_config["slug"] == "demo"
    assert prompted_config["_copy_without_render"] == ["*.png"]


def test_variable_rendering_propagates_errors_for_undefined_variables():
    environment = StrictEnvironment()
    undefined_template = "{{ cookiecutter.missing }}"

    with pytest.raises(UndefinedError):
        render_variable(
            environment,
            undefined_template,
            {},
        )


def test_nested_template_selection_rejects_absolute_template_paths(tmp_path):
    template_context = {
        "cookiecutter": {
            "templates": {
                "bad": {
                    "path": str(tmp_path),
                },
            },
        },
    }

    with pytest.raises(ValueError, match="Illegal template path"):
        choose_nested_template(
            template_context,
            tmp_path,
            no_input=True,
        )
