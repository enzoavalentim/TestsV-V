
from cookiecutter.__main__ import main as package_main
from cookiecutter.cli import main as command_line_main


def test_package_entrypoint_matches_cli_main():
    entrypoint = package_main
    cli_entrypoint = command_line_main

    assert entrypoint == cli_entrypoint
    assert entrypoint is cli_entrypoint
