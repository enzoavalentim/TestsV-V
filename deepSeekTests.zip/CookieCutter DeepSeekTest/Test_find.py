import pytest

from cookiecutter.environment import StrictEnvironment
from cookiecutter.exceptions import NonTemplatedInputDirException
from cookiecutter.find import find_template


def test_find_template_identifies_directory_with_cookiecutter_variable(tmp_path):
    templated_directory = tmp_path / "{{ cookiecutter.project_slug }}"
    templated_directory.mkdir()

    environment = StrictEnvironment()
    discovered_template = find_template(tmp_path, environment)

    assert discovered_template == templated_directory


def test_find_template_rejects_directory_without_template_variables(tmp_path):
    ordinary_directory = tmp_path / "plain"
    ordinary_directory.mkdir()

    environment = StrictEnvironment()

    with pytest.raises(NonTemplatedInputDirException):
        find_template(tmp_path, environment)
