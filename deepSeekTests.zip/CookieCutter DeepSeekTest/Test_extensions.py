import json
import re
import uuid

from jinja2 import Environment

from cookiecutter.environment import StrictEnvironment
from cookiecutter.extensions import TimeExtension


def test_template_filters_serialize_json_and_generate_valid_slugs():
    environment = StrictEnvironment()
    context = {"value": {"b": 1, "a": 2}}

    rendered_json = environment.from_string(
        "{{ value|jsonify(0) }}"
    ).render(**context)

    rendered_slug = environment.from_string(
        "{{ value|slugify }}"
    ).render(value="Hello World!")

    assert json.loads(rendered_json) == {"a": 2, "b": 1}
    assert rendered_slug == "hello-world"


def test_template_globals_generate_valid_random_strings_and_uuids():
    environment = StrictEnvironment()

    random_string = environment.globals["random_ascii_string"](12)
    generated_uuid = environment.globals["uuid4"]()

    assert len(random_string) == 12
    assert random_string.isalpha()
    assert str(uuid.UUID(generated_uuid)) == generated_uuid


def test_time_extension_renders_current_year_in_four_digit_format():
    environment = Environment(extensions=[TimeExtension])
    template = environment.from_string("{% now 'UTC', '%Y' %}")

    rendered_year = template.render()

    assert re.fullmatch(r"\d{4}", rendered_year)
