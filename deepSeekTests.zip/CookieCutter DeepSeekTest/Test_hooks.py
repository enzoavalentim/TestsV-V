import errno
import os

import pytest

from cookiecutter import hooks
from cookiecutter.exceptions import FailedHookException


def test_hook_validation_accepts_supported_names_and_rejects_invalid_files():
    valid_script = "pre_gen_project.py"
    backup_script = "pre_gen_project.py~"
    unsupported_script = "unknown.py"

    assert hooks.valid_hook(valid_script, "pre_gen_project") is True
    assert hooks.valid_hook(backup_script, "pre_gen_project") is False
    assert hooks.valid_hook(unsupported_script, "unknown") is False


def test_hook_discovery_returns_absolute_path_for_requested_script(
    tmp_path,
    monkeypatch,
):
    hooks_directory = tmp_path / "hooks"
    hooks_directory.mkdir()

    requested_hook = hooks_directory / "pre_gen_project.py"
    unrelated_hook = hooks_directory / "post_gen_project.py"

    requested_hook.write_text("print('ok')", encoding="utf-8")
    unrelated_hook.write_text("print('skip')", encoding="utf-8")

    monkeypatch.chdir(tmp_path)

    discovered_hooks = hooks.find_hook("pre_gen_project")
    expected_path = os.path.abspath(requested_hook)

    assert discovered_hooks == [expected_path]


def test_script_execution_raises_exception_when_hook_exits_with_error(
    tmp_path,
):
    hook_script = tmp_path / "hook.sh"
    hook_script.write_text(
        "#!/bin/sh\nexit 1\n",
        encoding="utf-8",
    )

    with pytest.raises(FailedHookException):
        hooks.run_script(str(hook_script), tmp_path)


def test_script_execution_translates_enoexec_into_hook_exception(
    monkeypatch,
    tmp_path,
):
    hook_script = tmp_path / "hook.sh"
    hook_script.write_text("", encoding="utf-8")

    class ExecutableLaunchError:
        def __init__(self, *_args, **_kwargs):
            raise OSError(errno.ENOEXEC, "bad executable")

    monkeypatch.setattr(
        hooks.subprocess,
        "Popen",
        ExecutableLaunchError,
    )

    with pytest.raises(
        FailedHookException,
        match="missing a shebang",
    ):
        hooks.run_script(str(hook_script), tmp_path)
